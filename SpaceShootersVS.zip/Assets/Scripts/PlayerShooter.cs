using UnityEngine;

public class PlayerShooter : MonoBehaviour
{
    [Header("Referencias")]
    public Transform firePoint;          // arrastra FirePoint (punta)
    public GameObject projectilePrefab;  // arrastra el prefab Projectile

    [Header("Config SPACE")]
    public float bulletSpeed = 12f;      // velocidad de la bala (Space)
    public float cooldown = 0.2f;        // tiempo entre disparos (Space)

    [Header("Config S (aparecer en el centro)")]
    public bool sBulletMoves = false;    // ¿la bala de S se mueve?
    public float sBulletSpeed = 8f;      // velocidad si sBulletMoves = true

    float nextShootTime;

    void Update()
    {
        // --- ESPACIO: Disparo desde FirePoint en la dirección del Player ---
        if (Time.time >= nextShootTime && Input.GetKeyDown(KeyCode.Space))
        {
            ShootFromFirePoint();
            nextShootTime = Time.time + cooldown;
        }

        // --- S: Aparece una bala en el centro del Player ---
        if (Input.GetKeyDown(KeyCode.S))
        {
            SpawnBulletAtCenter();
        }
    }

    void ShootFromFirePoint()
    {
        if (!firePoint || !projectilePrefab) return;

        GameObject go = Instantiate(projectilePrefab, firePoint.position, firePoint.rotation);
        if (go.TryGetComponent<Rigidbody2D>(out var rb))
        {
            rb.linearVelocity = (Vector2)firePoint.up * bulletSpeed;
        }
    }

    void SpawnBulletAtCenter()
    {
        if (!projectilePrefab) return;

        GameObject go = Instantiate(projectilePrefab, transform.position, Quaternion.identity);

        if (sBulletMoves && go.TryGetComponent<Rigidbody2D>(out var rb))
        {
            rb.linearVelocity = (Vector2)transform.up * sBulletSpeed;
        }
        else if (go.TryGetComponent<Rigidbody2D>(out var rbStill))
        {
            // Por defecto, la bala de S NO se mueve
            rbStill.linearVelocity = Vector2.zero;
        }
    }
}
