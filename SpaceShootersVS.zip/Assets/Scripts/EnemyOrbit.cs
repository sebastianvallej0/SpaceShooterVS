using UnityEngine;

public class EnemyOrbit : MonoBehaviour
{
    public Transform target;          // Asigna el Player
    public float radius = 3f;         // Radio de la �rbita
    public float angularSpeed = 90f;  // grados/seg
    public bool lookAtPlayer = true;  // que mire hacia el Player

    float angle;

    void Start()
    {
        if (target == null)
        {
            var p = GameObject.FindWithTag("Player");
            if (p != null) target = p.transform;
        }
        angle = Random.Range(0f, Mathf.PI * 2f);
    }

    void LateUpdate()
    {
        if (target == null) return;

        angle += (angularSpeed * Mathf.Deg2Rad) * Time.deltaTime;

        Vector2 offset = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius;
        transform.position = (Vector2)target.position + offset;

        if (lookAtPlayer)
            transform.up = (target.position - transform.position).normalized;
    }
}
