using UnityEngine;

public class DestroyOnHit : MonoBehaviour
{
    [Tooltip("Da�o que hace la bala al golpear un Enemy con EnemyHealth.")]
    public int damage = 1;

    private void OnTriggerEnter2D(Collider2D other)
    {
        // 1) Enemigos con vida (sube oleadas)
        if (other.CompareTag("Enemy"))
        {
            var health = other.GetComponent<EnemyHealth>();
            if (health != null)
            {
                health.Hit(damage);        // avisa al GameController al morir
            }
            else
            {
                // Por si alg�n enemigo no tiene EnemyHealth
                GameController.Instance?.OnEnemyKilled(null);
                Destroy(other.gameObject);
            }

            Destroy(gameObject);           // destruye la bala
            return;
        }

        // 2) Rocas / asteroides u otros objetos que quieras desaparecer
        if (other.CompareTag("Asteroid"))
        {
            Destroy(other.gameObject);     // elimina la roca
            Destroy(gameObject);           // elimina la bala
            return;
        }
    }
}
