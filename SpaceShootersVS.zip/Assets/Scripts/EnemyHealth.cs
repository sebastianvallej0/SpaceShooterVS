using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int hp = 1;
    bool reported = false;

    public void Hit(int damage = 1)
    {
        if (reported) return;

        hp -= damage;
        if (hp <= 0)
        {
            ReportAndDie();
        }
    }

    void ReportAndDie()
    {
        if (!reported)
        {
            GameController.Instance?.OnEnemyKilled(this);
            reported = true;
        }
        Destroy(gameObject);
    }

    void OnDestroy()
    {
        if (Application.isPlaying && !reported)
        {
            GameController.Instance?.OnEnemyKilled(this);
            reported = true;
        }
    }
}
