using UnityEngine;

public class BulletAutoDestroy : MonoBehaviour
{
    public float lifetime = 3f;
    void Start() => Destroy(gameObject, lifetime);
}
