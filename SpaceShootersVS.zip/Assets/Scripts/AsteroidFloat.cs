using UnityEngine;

public class AsteroidFloat : MonoBehaviour
{
    [Header("Movimiento lento y aleatorio")]
    public float moveSpeed = 0.05f;      // velocidad de desplazamiento
    public float rotationSpeed = 10f;    // velocidad de rotaci�n
    public float floatAmplitude = 0.05f; // amplitud de oscilaci�n (vaiv�n)
    public float floatFrequency = 1f;    // frecuencia del vaiv�n

    Vector3 startPos;
    Vector2 randomDir;
    float randomRotation;

    void Start()
    {
        startPos = transform.position;

        // direcci�n aleatoria muy leve
        randomDir = new Vector2(
            Random.Range(-1f, 1f),
            Random.Range(-1f, 1f)
        ).normalized * moveSpeed;

        // rotaci�n aleatoria
        randomRotation = Random.Range(-rotationSpeed, rotationSpeed);
    }

    void Update()
    {
        // movimiento suave y lento
        transform.position += (Vector3)(randomDir * Time.deltaTime);

        // rotaci�n lenta
        transform.Rotate(0f, 0f, randomRotation * Time.deltaTime);

        // vaiv�n sutil (como si flotara)
        float offset = Mathf.Sin(Time.time * floatFrequency) * floatAmplitude;
        transform.position = new Vector3(
            transform.position.x,
            startPos.y + offset,
            transform.position.z
        );
    }
}
