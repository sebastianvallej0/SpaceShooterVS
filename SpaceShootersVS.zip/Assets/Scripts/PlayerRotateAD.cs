using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerRotateAD : MonoBehaviour
{
    public float rotateSpeed = 180f; // grados/seg
    private Rigidbody2D rb;
    private float input; // -1 (D) ... 0 ... +1 (A)

    void Awake() => rb = GetComponent<Rigidbody2D>();

    void Update()
    {
        // A = izquierda (CCW, positivo), D = derecha (CW, negativo)
        input = 0f;
        if (Input.GetKey(KeyCode.A)) input = 1f;
        if (Input.GetKey(KeyCode.D)) input = -1f;
    }

    void FixedUpdate()
    {
        float delta = rotateSpeed * input * Time.fixedDeltaTime;
        rb.MoveRotation(rb.rotation + delta); // usa f�sica: suave y sin jitter
    }
}
