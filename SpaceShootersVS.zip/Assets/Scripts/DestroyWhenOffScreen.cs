using UnityEngine;

public class DestroyWhenOffScreen : MonoBehaviour
{
    private bool isOffScreen = false;

    void OnBecameInvisible()
    {
        // Este evento se ejecuta autom�ticamente cuando el objeto
        // deja de ser visible por cualquier c�mara en la escena
        if (!isOffScreen)
        {
            isOffScreen = true;
            Invoke(nameof(DestroySelf), 1f); // destruye 1 segundo despu�s
        }
    }

    void OnBecameVisible()
    {
        // Reinicia el estado si vuelve a aparecer
        isOffScreen = false;
    }

    void DestroySelf()
    {
        Destroy(gameObject);
    }
}
