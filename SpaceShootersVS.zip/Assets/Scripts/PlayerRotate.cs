using UnityEngine;

public class PlayerRotate : MonoBehaviour
{
    public float rotateSpeed = 180f; // grados/seg

    void Update()
    {
        transform.Rotate(0f, 0f, rotateSpeed * Time.deltaTime);
    }
}
