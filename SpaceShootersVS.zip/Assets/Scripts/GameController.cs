using UnityEngine;
using System.Collections.Generic;

public class GameController : MonoBehaviour
{
    public static GameController Instance { get; private set; }

    [Header("Spawning")]
    public GameObject enemyPrefab;   // arrastra tu prefab Enemy
    public Transform player;         // arrastra el Player
    public int maxEnemies = 4;       // tope simult�neo
    public float spawnRadiusMin = 3f;
    public float spawnRadiusMax = 6f;

    int totalKills = 0;
    readonly List<EnemyHealth> alive = new List<EnemyHealth>();

    void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }
    }

    void Start()
    {
        EnsureTargetEnemyCount(); // Empieza con 1 enemigo
    }

    // Llamado por EnemyHealth cuando muere (o por fallback)
    public void OnEnemyKilled(EnemyHealth whoDied)
    {
        // quitar referencia si ven�a
        if (whoDied != null) alive.Remove(whoDied);

        // limpieza extra por seguridad
        alive.RemoveAll(e => e == null);

        totalKills++;
        EnsureTargetEnemyCount();
    }

    void EnsureTargetEnemyCount()
    {
        // Objetivo = min(1 + kills, maxEnemies)
        int target = Mathf.Min(1 + totalKills, maxEnemies);

        // limpieza por seguridad
        alive.RemoveAll(e => e == null);

        while (alive.Count < target)
            SpawnOneEnemy();
    }

    void SpawnOneEnemy()
    {
        if (enemyPrefab == null || player == null) { Debug.LogWarning("[GC] Falta enemyPrefab o player."); return; }

        // Posici�n aleatoria alrededor del jugador
        float r = Random.Range(spawnRadiusMin, spawnRadiusMax);
        float ang = Random.Range(0f, Mathf.PI * 2f);
        Vector3 pos = player.position + new Vector3(Mathf.Cos(ang), Mathf.Sin(ang), 0f) * r;

        var go = Instantiate(enemyPrefab, pos, Quaternion.identity);

        // Si usas un script de �rbita, ap�ntalo al player
        var orbit = go.GetComponent<EnemyOrbit>();
        if (orbit != null) orbit.target = player;   // <<-- tu EnemyOrbit usa 'target' (min�scula)

        // Registrar como vivo
        var hp = go.GetComponent<EnemyHealth>();
        if (hp != null) alive.Add(hp);
        else Debug.LogWarning("[GC] El enemyPrefab no tiene EnemyHealth.");
    }
}

